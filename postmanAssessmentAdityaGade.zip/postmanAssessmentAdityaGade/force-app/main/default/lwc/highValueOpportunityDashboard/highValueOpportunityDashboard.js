import { LightningElement, track } from 'lwc';
import getRecentClosedWonOpportunities from '@salesforce/apex/OpportunityRetryController.getRecentClosedWonOpportunities';
import getFailedProcessingErrors from '@salesforce/apex/OpportunityRetryController.getFailedProcessingErrors';
import retryOpportunityProcessing from '@salesforce/apex/OpportunityRetryController.retryOpportunityProcessing';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class HighValueOpportunityDashboard extends LightningElement {
    @track recentOpportunities = [];
    @track processingErrors = [];
    @track isLoading = false;
    @track loadError;
    //recordIds = []; add later for bulkification

    connectedCallback() {
        this.loadData();
    }

    async loadData() {
        this.isLoading = true;
        this.loadError = undefined;

        try {
            this.recentOpportunities  = await getRecentClosedWonOpportunities();
        
        } catch (error) {
            this.loadError = 'Failed to load recent opportunities.';
            console.error(error);//show toast
        }

        try {
            this.processingErrors  = await getFailedProcessingErrors();
        } catch (error) {
            this.loadError = this.loadError || 'Failed to load processing errors.';
            console.error(error); //showToast
        }

        this.isLoading = false;
    }

    async handleRetry(event) {
        const opportunityId = event.detail;
        this.isLoading = true;
        //this.recordIds = [...this.recordIds, opportunityId];
        try {
            const result = await retryOpportunityProcessing({ opportunityId });

            if (result.success) {
                this.showToast('Retry Successful', result.message, 'success');
            } else {
                this.showToast('Retry Failed', result.message, 'warning');
            }

            await this.loadData(); // reload after retry as well as fail for the errOP
        } catch (error) {
            this.showToast('Unable to attempt retry ', error?.body?.message || 'Something went wrong.', 'error');
            console.error(error);
        } finally {
            this.isLoading = false;
        }
    }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
}