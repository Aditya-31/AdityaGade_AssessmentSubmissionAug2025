import { LightningElement, api } from 'lwc';
//import { loadStyle } from 'lightning/platformResourceLoader';
//import tableStyles from '@salesforce/resourceUrl/CustomTableStyles'; // Optional custom CSS

const COLUMNS = [
  { label: 'Opportunity Name', fieldName: 'opportunityUrl', type: 'url', typeAttributes: { label: { fieldName: 'Name' },target: '_blank'} },
  { label: 'Amount', fieldName: 'Amount', type: 'currency' },
  { label: 'Closed Date', fieldName: 'CloseDate', type: 'date' },
  { label: 'Reason', fieldName: 'Closed_Won_Reason__c', type: 'text' },
  {
    label: 'Processed',
    fieldName: 'High_Value_Processed__c',
    type: 'boolean',
    cellAttributes: {
      iconName: { fieldName: 'statusIcon' },
      iconPosition: 'left'
    }
  }
];

export default class ClosedWonOpportunityList extends LightningElement {
  @api opportunities;

  get noErrors() {
      return this.opportunities && this.opportunities.length > 0;
  }

  get columns() {
    // Enhance display with icons for processed field
    return COLUMNS;
  }

  get tableData() {
        return this.opportunities.map(opp => ({
            ...opp,
            opportunityUrl: '/' + opp.Id
        }));
    }
}