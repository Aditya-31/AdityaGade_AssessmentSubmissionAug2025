import { LightningElement, api, track } from 'lwc';

export default class ProcessingErrorList extends LightningElement {
    @api errors = [];
    @track page = 1;
    pageSize = 7; // can be increased if needed

    columns = [
        {
            label: 'Opportunity',
            fieldName: 'errorUrl',
            type: 'url',
            typeAttributes: {
                label: { fieldName: 'OpportunityName' },
                target: '_blank'
            }
        },
        { label: 'Error Message', fieldName: 'Error_Message__c', type: 'text' },
        { label: 'Occurred On', fieldName: 'CreatedDate', type: 'date' },
        {
            label: 'Retry Processing',
            type: 'button',
            typeAttributes: {
                label: 'Retry',
                name: 'retry',
                title: 'Retry Processing',
                variant: 'brand'
            }
        }
    ];

    get noErrors() {
        return this.errors && this.errors.length > 0;
    }

    get maxPage() {
        return Math.ceil(this.errors.length / this.pageSize);
    }

    get tableData() {
        const start = (this.page - 1) * this.pageSize;
        const end = start + this.pageSize;
        return this.errors.slice(start, end).map(err => ({
            ...err,
            OpportunityName: err.Opportunity__r?.Name || 'N/A',
            errorUrl: '/' + err.Id
        }));
    }

    get isPrevDisabled() {
        return this.page <= 1;
    }

    get isNextDisabled() {
        return this.page >= this.maxPage;
    }

    handlePrev() {
        if (this.page > 1) {
            this.page--;
        }
    }

    handleNext() {
        if (this.page < this.maxPage) {
            this.page++;
        }
    }

    handleRowAction(event) {
        const opportunityId = event.detail.row.Opportunity__c;
        this.dispatchEvent(new CustomEvent('retried', { detail: opportunityId }));
    }
}