declare module "@salesforce/apex/OpportunityRetryController.retryOpportunityProcessing" {
  export default function retryOpportunityProcessing(param: {opportunityId: any}): Promise<any>;
}
declare module "@salesforce/apex/OpportunityRetryController.getFailedProcessingErrors" {
  export default function getFailedProcessingErrors(): Promise<any>;
}
declare module "@salesforce/apex/OpportunityRetryController.getRecentClosedWonOpportunities" {
  export default function getRecentClosedWonOpportunities(): Promise<any>;
}
